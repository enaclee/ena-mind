package com.enamind.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.enamind.ai.core.AppState
import com.enamind.ai.core.Settings
import com.enamind.ai.ui.EngineChatScreen
import com.enamind.ai.ui.EnaMindTheme
import com.enamind.ai.ui.MarketMonitor
import com.enamind.ai.ui.OnboardingScreen
import com.enamind.ai.ui.RadarSentinelScreen
import com.enamind.ai.ui.SettingsScreen

/**
 * ENA-MIND v8.2 «TELEGRAM» — редизайн по запросу пользователя:
 *   ЧАТ     — диалог с движком: кнопки-команды (прогноз/тренд/агенты/ончейн/
 *             24ч/путь A→Б/совет), ответы пузырями сообщений;
 *   РЫНОК   — живые данные: график OHLCV, стакан, order flow, метрики, новости;
 *   НАСТРОЙКИ — тема, API-связи, скилл, история, память.
 * Блок «Сделки» (приватные ключи Bybit) удалён — приложение аналитическое.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val state = EnaApp.get().state
        state.start()
        setContent {
            var themeSetting by remember { mutableStateOf(state.settings.theme) }
            var settingsTab by remember { mutableIntStateOf(0) }
            var onboardingDone by remember { mutableStateOf(state.settings.onboardingDone) }
            val toast by state.toast.collectAsState()

            // короткие уведомления гаснут сами
            androidx.compose.runtime.LaunchedEffect(toast) {
                if (toast != null) {
                    kotlinx.coroutines.delay(2500)
                    state.toast(null)
                }
            }

            EnaMindTheme(themeSetting) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    // честные insets-отступы: контент не залезает под статусбар и кнопки
                    Box(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                        if (!onboardingDone) {
                            // v8.1 (ТЗ §3): первый запуск — объяснение и осознанный выбор,
                            // никаких системных диалогов «просто так»
                            OnboardingScreen(state) { onboardingDone = true }
                        } else {
                            MainScaffold(
                                state = state,
                                toast = toast,
                                onThemeChange = { themeSetting = it },
                                settingsTab = settingsTab,
                                onOpenSettingsTab = { settingsTab = it }
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class TabSpec(
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainScaffold(
    state: AppState,
    toast: String?,
    onThemeChange: (Settings.Theme) -> Unit,
    settingsTab: Int,
    onOpenSettingsTab: (Int) -> Unit
) {
    // 0 ЧАТ | 1 РЫНОК | 2 РАДАР | 3 НАСТРОЙКИ
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by remember { mutableStateOf(false) }

    BackHandler(enabled = tab != 0) {
        settingsOpen = false
        tab = 0
    }

    // внешний запрос на открытие вкладки настроек (например, ИСТОРИЯ из чата)
    androidx.compose.runtime.LaunchedEffect(settingsTab, settingsOpen) {
        if (settingsOpen) tab = 3
    }

    val tabs = listOf(
        TabSpec("ЧАТ", Icons.AutoMirrored.Outlined.Chat),
        TabSpec("РЫНОК", Icons.Outlined.BarChart),
        TabSpec("РАДАР", Icons.Outlined.Radar),
        TabSpec("НАСТРОЙКИ", Icons.Outlined.Settings)
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // содержимое вкладки занимает весь экран — без пустого места
            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                when (tab) {
                    0 -> EngineChatScreen(state = state)
                    1 -> MarketMonitor(state = state)
                    2 -> RadarSentinelScreen(state = state)
                    else -> SettingsScreen(
                        state = state,
                        onThemeChange = onThemeChange,
                        onClose = { settingsOpen = false; tab = 0 },
                        initialTab = if (settingsOpen) settingsTab else 0
                    )
                }
            }

            // нижняя навигация Telegram-стиля
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { settingsOpen = false; tab = i },
                        modifier = Modifier.testTag("nav_tab_$i"),
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        )
                    )
                }
            }
        }

        // короткие уведомления
        toast?.let { msg ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(msg, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}
