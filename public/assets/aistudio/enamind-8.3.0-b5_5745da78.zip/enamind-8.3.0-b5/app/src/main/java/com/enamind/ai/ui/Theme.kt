package com.enamind.ai.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.enamind.ai.core.Settings

/**
 * Палитра ENA-MIND v8.3:
 * — Ночной режим (BLACK): строго чёрно-белый монохром AMOLED (#000000 фон,
 *   #0D0D0D / #181818 поверхности, #FFFFFF чистый белый акцент, нейтральные серые тона,
 *   без синих/голубых оттенков).
 * — Дневной режим (WHITE): чистый белый/графитовый монохром.
 * — Семантические цвета рынка (#00E5A0 / #FF4D5E / #FBBF24) используются только
 *   для свечей графика, направлений роста/падения, вероятностей и риск-алертов.
 */
private val MonoWhite = Color(0xFFFFFFFF)
private val MonoInk = Color(0xFF111111)
private val Green = Color(0xFF00E5A0)
private val Red = Color(0xFFFF4D5E)
private val Yellow = Color(0xFFFBBF24)

private val DarkScheme = darkColorScheme(
    primary = MonoWhite,
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF222222),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFE5E5E5),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF1F1F1F),
    onSecondaryContainer = Color(0xFFF5F5F5),
    tertiary = Yellow,
    onTertiary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF0C0C0C),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF181818),
    onSurfaceVariant = Color(0xFFA3A3A3),
    outline = Color(0xFF3A3A3A),
    outlineVariant = Color(0xFF242424),
    error = Red,
    onError = Color.White
)

private val LightScheme = lightColorScheme(
    primary = MonoInk,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDEDED),
    onPrimaryContainer = Color(0xFF111111),
    secondary = Color(0xFF262626),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF0F0F0),
    onSecondaryContainer = Color(0xFF111111),
    tertiary = Color(0xFFD97706),
    onTertiary = Color.White,
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111111),
    surface = Color(0xFFF7F7F7),
    onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFECECEC),
    onSurfaceVariant = Color(0xFF525252),
    outline = Color(0xFFD4D4D4),
    outlineVariant = Color(0xFFE4E4E4),
    error = Color(0xFFDC2626),
    onError = Color.White
)

private val AppTypography = Typography(
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 13.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp),
    labelMedium = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun EnaMindTheme(theme: Settings.Theme, content: @Composable () -> Unit) {
    val dark = when (theme) {
        Settings.Theme.BLACK -> true
        Settings.Theme.WHITE -> false
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}

val Color.Companion.EnaGreen: Color get() = Green
val Color.Companion.EnaRed: Color get() = Red
val Color.Companion.EnaYellow: Color get() = Yellow
val Color.Companion.TgBlue: Color get() = MonoWhite
